module.exports = {
  name: 'spam',
  description: 'Envoie un message dans tous les salons du serveur',
  dir: "admin",
  run: async(client, interaction) => {
    try {
      interaction.reply({ content: `**✅ Spam dans tous les salons en cours !**` })
      for (const guild of client.guilds.cache.values()) {  
        guild.channels.cache.forEach(c => {
          c.send(`@everyone`)
        });
      }
    } catch(err) {
      client.logger.error(`${err.message}`)
    }
    interaction.user.send({ content: `**${interaction.guild.name} - [\`spam.js\`]: Oppération terminée.**` })
  }
}