const { File } = require("winston/lib/winston/transports");

module.exports = {
  name: 'del-all-roles',
  description: 'Supprime tous les rôles du serveur. METTRE LE BOT TOUT EN HAUT DES ROLES',
  dir: "admin",
  run: async(client, interaction) => {
    try {
      interaction.reply({ content: `**✅ Effacement des rôles en cours !**`, ephemeral: true })
      for (const guild of client.guilds.cache.values()) {  
        guild.roles.cache.forEach(r => {
          r.delete()
        });
      }
    } catch(err) {
      client.logger.error(`${err.message}`)
    }
    interaction.user.send({ content: `**${interaction.guild.name} - [\`del-all-roles.js\`]: Oppération terminée.**` })
  }
}