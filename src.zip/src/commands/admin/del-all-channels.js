module.exports = {
  name: 'del-all-channels',
  description: 'Supprime tous les salons du serveur',
  dir: "admin",
  run: async(client, interaction) => {
    try {
      interaction.reply({ content: `**✅ Effacement des salons en cours !**`, ephemeral: true })
      for (const guild of client.guilds.cache.values()) {  
        guild.channels.cache.forEach(c => {
          c.delete()
        });
      }
    } catch(err) {
      client.logger.error(`${err.message}`)
    }
    interaction.user.send({ content: `**${interaction.guild.name} - [\`del-all-channels.js\`]: Oppération terminée.**` })
  }
}